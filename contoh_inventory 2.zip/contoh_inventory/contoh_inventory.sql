/*
Navicat MySQL Data Transfer

Source Server         : lokal
Source Server Version : 50141
Source Host           : localhost:3306
Source Database       : contoh_inventory

Target Server Type    : MYSQL
Target Server Version : 50141
File Encoding         : 65001

Date: 2012-08-30 16:29:03
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admins`
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `blokir` enum('Y','N') CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  `tempatlahir` varchar(50) DEFAULT NULL,
  `tgllahir` date DEFAULT NULL,
  `hp` varchar(30) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `foto` varchar(30) DEFAULT NULL,
  `create` datetime DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `ipaddress` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('0', 'cfcd208495d565ef66e7dff9f98764da', 'Nama Lengkap', 'admin', 'N', null, null, null, null, null, null, '2012-08-24 20:42:24', '2012-08-25 14:28:57', '::1');
INSERT INTO `admins` VALUES ('1', 'c4ca4238a0b923820dcc509a6f75849b', 'Deddy Rusdiansyah', 'admin', 'N', null, null, null, null, '1.jpg', null, '2012-08-24 20:54:56', '2012-08-25 14:20:53', '::1');
INSERT INTO `admins` VALUES ('2', 'd41d8cd98f00b204e9800998ecf8427e', 'Salsabila', 'user', 'N', null, null, null, null, null, null, '2012-08-24 20:56:12', null, null);
INSERT INTO `admins` VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'admin', 'N', null, null, null, null, 'admin.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2012-08-30 07:58:00', '::1');
INSERT INTO `admins` VALUES ('danis', 'c4ca4238a0b923820dcc509a6f75849b', 'danish', 'admin', 'N', null, null, null, null, null, null, null, null, null);
INSERT INTO `admins` VALUES ('deddy', '8b509a9032c0160d358f61473b4f7c57', 'Deddy Rusdiansyah,S.Kom', 'admin', 'N', null, null, null, null, null, '0000-00-00 00:00:00', '2012-05-04 22:29:24', '2012-05-04 22:30:20', '::1');
INSERT INTO `admins` VALUES ('hdt', '2ad202b4999db3676097a15e7a8d1982', 'help desk technology', 'admin', 'N', null, null, null, null, null, '0000-00-00 00:00:00', '2012-05-09 17:58:23', '0000-00-00 00:00:00', '');
INSERT INTO `admins` VALUES ('mentari', 'c4ca4238a0b923820dcc509a6f75849b', 'Mentari Aqilah', 'admin', 'N', null, null, null, null, null, null, null, null, null);
INSERT INTO `admins` VALUES ('udin', '6bec9c852847242e384a4d5ac0962ba0', 'Udin Sedunia', 'user', 'N', null, null, null, null, null, '0000-00-00 00:00:00', '2012-05-04 16:38:26', '2012-05-04 16:41:05', '::1');

-- ----------------------------
-- Table structure for `barang`
-- ----------------------------
DROP TABLE IF EXISTS `barang`;
CREATE TABLE `barang` (
  `kode_barang` char(15) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `satuan` char(10) NOT NULL,
  `harga_beli` bigint(20) NOT NULL,
  `harga_jual` bigint(20) NOT NULL,
  `stok_awal` int(11) NOT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of barang
-- ----------------------------
INSERT INTO `barang` VALUES ('123456', 'Sprite Kaleng', 'PCS', '5000', '5500', '10');
INSERT INTO `barang` VALUES ('B001', 'Hardisk 40Gb', 'PCS', '230000', '250000', '5');
INSERT INTO `barang` VALUES ('B002', 'Hardisk 60Gb', 'BOX', '240000', '260000', '4');
INSERT INTO `barang` VALUES ('B003', 'Hardisk 80Gb', 'PCS', '250000', '270000', '17');
INSERT INTO `barang` VALUES ('B005', 'Keyboard PS2', 'PCS', '35000', '45000', '70');
INSERT INTO `barang` VALUES ('B006', 'Mouse PS2', 'PCS', '25000', '30000', '0');
INSERT INTO `barang` VALUES ('B007', 'Processor Dual Core', 'PCS', '1200000', '1400000', '10');
INSERT INTO `barang` VALUES ('B008', 'Prosesor Core 2 Duo', 'PCS', '1500000', '1720000', '5');
INSERT INTO `barang` VALUES ('B009', 'Sampurna Mild', 'PCS', '10000', '12000', '5');
INSERT INTO `barang` VALUES ('B010', 'Dji Sam Soe', 'PCS', '9000', '11000', '5');
INSERT INTO `barang` VALUES ('B011', 'Kopi Kapal Api', 'PCS', '450', '500', '10');

-- ----------------------------
-- Table structure for `d_beli`
-- ----------------------------
DROP TABLE IF EXISTS `d_beli`;
CREATE TABLE `d_beli` (
  `idbeli` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodebeli` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbeli` int(11) NOT NULL,
  `hargabeli` double NOT NULL,
  PRIMARY KEY (`idbeli`),
  KEY `kodebeli` (`kodebeli`),
  KEY `kode_barang` (`kode_barang`),
  CONSTRAINT `d_beli_ibfk_1` FOREIGN KEY (`kodebeli`) REFERENCES `h_beli` (`kodebeli`),
  CONSTRAINT `d_beli_ibfk_2` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of d_beli
-- ----------------------------
INSERT INTO `d_beli` VALUES ('2', 'BL00002', 'B002', '2', '240000');
INSERT INTO `d_beli` VALUES ('3', 'BL00003', 'B005', '2', '35000');
INSERT INTO `d_beli` VALUES ('4', 'BL00003', 'B009', '1', '10000');
INSERT INTO `d_beli` VALUES ('5', 'BL00004', 'B007', '2', '1200000');
INSERT INTO `d_beli` VALUES ('6', 'BL00004', 'B010', '2', '9000');
INSERT INTO `d_beli` VALUES ('7', 'BL00005', 'B006', '2', '25000');
INSERT INTO `d_beli` VALUES ('8', 'BL00005', 'B008', '1', '1500000');
INSERT INTO `d_beli` VALUES ('12', 'BL00006', 'B003', '2', '250000');
INSERT INTO `d_beli` VALUES ('13', 'BL00006', 'B010', '3', '9000');
INSERT INTO `d_beli` VALUES ('14', 'BL00007', 'B007', '2', '1200000');
INSERT INTO `d_beli` VALUES ('16', 'BL00007', 'B003', '2', '250000');
INSERT INTO `d_beli` VALUES ('17', 'BL00008', '123456', '2', '5000');
INSERT INTO `d_beli` VALUES ('18', 'BL00008', 'B009', '2', '10000');
INSERT INTO `d_beli` VALUES ('19', 'BL00006', 'B005', '2', '35000');
INSERT INTO `d_beli` VALUES ('20', 'BL00006', 'B009', '5', '10000');
INSERT INTO `d_beli` VALUES ('21', 'BL00004', 'B005', '10', '35000');
INSERT INTO `d_beli` VALUES ('31', 'BL00001', '123456', '5', '5000');
INSERT INTO `d_beli` VALUES ('32', 'BL00001', 'B006', '5', '25000');

-- ----------------------------
-- Table structure for `d_jual`
-- ----------------------------
DROP TABLE IF EXISTS `d_jual`;
CREATE TABLE `d_jual` (
  `idjual` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodejual` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmljual` int(11) NOT NULL,
  `hargajual` double NOT NULL,
  PRIMARY KEY (`idjual`),
  KEY `kode_barang` (`kode_barang`),
  KEY `kodejual` (`kodejual`),
  CONSTRAINT `d_jual_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`),
  CONSTRAINT `d_jual_ibfk_2` FOREIGN KEY (`kodejual`) REFERENCES `h_jual` (`kodejual`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of d_jual
-- ----------------------------
INSERT INTO `d_jual` VALUES ('2', 'JL00001', 'B001', '2', '230000');
INSERT INTO `d_jual` VALUES ('3', 'JL00001', 'B002', '2', '240000');
INSERT INTO `d_jual` VALUES ('5', 'JL00002', 'B005', '10', '35000');
INSERT INTO `d_jual` VALUES ('6', 'JL00003', 'B006', '2', '25000');
INSERT INTO `d_jual` VALUES ('7', 'JL00004', 'B007', '2', '1200000');
INSERT INTO `d_jual` VALUES ('8', 'JL00004', 'B009', '5', '10000');
INSERT INTO `d_jual` VALUES ('9', 'JL00004', 'B011', '2', '450');
INSERT INTO `d_jual` VALUES ('10', 'JL00005', 'B001', '3', '230000');
INSERT INTO `d_jual` VALUES ('11', 'JL00005', 'B002', '2', '240000');

-- ----------------------------
-- Table structure for `h_beli`
-- ----------------------------
DROP TABLE IF EXISTS `h_beli`;
CREATE TABLE `h_beli` (
  `kodebeli` char(15) NOT NULL,
  `tglbeli` date NOT NULL,
  `kode_supplier` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`kodebeli`),
  KEY `kode_supplier` (`kode_supplier`),
  KEY `username` (`username`),
  CONSTRAINT `h_beli_ibfk_1` FOREIGN KEY (`kode_supplier`) REFERENCES `supplier` (`kode_supplier`),
  CONSTRAINT `h_beli_ibfk_2` FOREIGN KEY (`username`) REFERENCES `admins` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of h_beli
-- ----------------------------
INSERT INTO `h_beli` VALUES ('BL00001', '2012-08-27', 'SP001', 'admin');
INSERT INTO `h_beli` VALUES ('BL00002', '2012-08-27', 'SP004', 'admin');
INSERT INTO `h_beli` VALUES ('BL00003', '2012-08-27', 'SP005', 'admin');
INSERT INTO `h_beli` VALUES ('BL00004', '2012-08-27', 'SP004', 'admin');
INSERT INTO `h_beli` VALUES ('BL00005', '2012-08-27', 'SP007', 'admin');
INSERT INTO `h_beli` VALUES ('BL00006', '2012-08-27', 'SP009', 'admin');
INSERT INTO `h_beli` VALUES ('BL00007', '2012-08-27', 'SP007', 'admin');
INSERT INTO `h_beli` VALUES ('BL00008', '2012-08-26', 'SP004', 'admin');

-- ----------------------------
-- Table structure for `h_jual`
-- ----------------------------
DROP TABLE IF EXISTS `h_jual`;
CREATE TABLE `h_jual` (
  `kodejual` char(15) NOT NULL,
  `tgljual` date NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`kodejual`),
  KEY `username` (`username`),
  CONSTRAINT `h_jual_ibfk_1` FOREIGN KEY (`username`) REFERENCES `admins` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of h_jual
-- ----------------------------
INSERT INTO `h_jual` VALUES ('JL00001', '2012-08-27', 'admin');
INSERT INTO `h_jual` VALUES ('JL00002', '2012-08-27', 'admin');
INSERT INTO `h_jual` VALUES ('JL00003', '2012-08-27', 'admin');
INSERT INTO `h_jual` VALUES ('JL00004', '2012-08-30', 'admin');
INSERT INTO `h_jual` VALUES ('JL00005', '2012-08-30', 'admin');

-- ----------------------------
-- Table structure for `supplier`
-- ----------------------------
DROP TABLE IF EXISTS `supplier`;
CREATE TABLE `supplier` (
  `kode_supplier` char(5) NOT NULL DEFAULT '',
  `nama_supplier` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  PRIMARY KEY (`kode_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of supplier
-- ----------------------------
INSERT INTO `supplier` VALUES ('SP001', 'Maju Terus,CV.', 'A.Yani 30 tes');
INSERT INTO `supplier` VALUES ('SP002', 'Maju Mundur,CV.', 'A.Yani 31');
INSERT INTO `supplier` VALUES ('SP003', 'Maju Lambat,PT.', 'A.Yani 32');
INSERT INTO `supplier` VALUES ('SP004', 'Deddy', 'Cimuncang Sidomuncul');
INSERT INTO `supplier` VALUES ('SP005', 'Jangan Dihapus', 'Makannya jangan diedit kebanayakalasdkal ');
INSERT INTO `supplier` VALUES ('SP006', 'Bantex', 'Dimana aja boleh');
INSERT INTO `supplier` VALUES ('SP007', 'Coba lagi dong', 'biar mantap');
INSERT INTO `supplier` VALUES ('SP008', 'Kapal Api', 'Jalan Mana Saja');
INSERT INTO `supplier` VALUES ('SP009', 'ITB Piksi Input', 'Serang');
INSERT INTO `supplier` VALUES ('SP010', 'Edifier', 'Serang');
INSERT INTO `supplier` VALUES ('SP011', 'Font Arial', 'Jakarta');
INSERT INTO `supplier` VALUES ('SP012', 'Font Verdana', 'Jakarta Selatan');
