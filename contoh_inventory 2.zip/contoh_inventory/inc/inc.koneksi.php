<?php
// panggil fungsi validasi xss dan injection
require_once('fungsi_validasi.php');
$server = "localhost"; 
$username = "root";  // sesuaikan dengan database mysal anda
$password = "root"; // sesuaikan dengan database mysal anda
$database = "contoh_inventory"; // sesuaikan dengan database yang anda buat.
$konek = mysql_connect($server, $username, $password) or die ("Gagal konek ke server MySQL" .mysql_error());
$bukadb = mysql_select_db($database) or die ("Gagal membuka database $database" .mysql_error());
// buat variabel untuk validasi dari file fungsi_validasi.php
$val = new Lokovalidasi;
?>