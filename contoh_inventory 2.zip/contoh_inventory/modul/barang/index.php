<script type="text/javascript" src="modul/barang/ajax.js"></script>
<style type="text/css">
.flexigrid div.fbutton .add {
	background: url(images/add.png) no-repeat center left;
}
.flexigrid div.fbutton .edit {
	background: url(images/edit.png) no-repeat center left;
}
.flexigrid div.fbutton .cmdedit {
	background: url(images/edit.png) no-repeat center left;
}

.flexigrid div.fbutton .delete {
	background: url(images/close.png) no-repeat center left;
}
.flexigrid div.fbutton .refresh {
	background: url(images/refresh.png) no-repeat center left;
}
.hilite{
   background-color: #FFF000;
}
</style>
<?php
echo "<div id='dalam_content'>
<div id='tampil_data'>
<table class=\"data\" id=\"data\" style=\"display: none\"></table>
</div>
</div>";
echo "<div id=\"form_input\" class=\"easyui-dialog\" title=\"Input Data\" style=\"padding:5px;width:520px;height:350px;\"
	data-options=\"closed:true,modal:true,buttons:'#dlg-buttons',resizable:false\">
	<table id='InputTable' width='100%'>
	<tr>
		<td>Kode Barang</td>
		<td>:&nbsp;<input type='text' name='kode' id='kode' size='20' maxlength='20' 
		class=\"easyui-validatebox\" data-options=\"required:true,validType:'length[1,20]'\" ></td>
	</tr>
	<tr>
		<td>Nama Barang</td>
		<td>:&nbsp;<input type='text' name='namabarang' id='namabarang' size='50' maxlength='50'
		class=\"easyui-validatebox\" data-options=\"required:true,validType:'length[1,20]'\"></td>
	</tr>
	<tr>
		<td>Level</td>
		<td>:&nbsp;<select name='satuan' id='satuan' class=\"input\" data-options=\"required:true\">
		<option value=''>-Pilih-</option>
		<option value='PCS'>PCS</option>
		<option value='UNIT'>UNIT</option>
		<option value='BOX'>BOX</option>
		<option value='DUS'>DUS</option>
		</select>
		</td>
	</tr>
	<tr>
		<td>Harga Beli</td>
		<td>:&nbsp;<input  id='hargabeli' size='10' maxlength='10'
		class=\"easyui-validatebox\" data-options=\"required:true,validType:'length[1,20]'\"></input></td>
	</tr>
	<tr>
		<td>Harga Jual</td>
		<td>:&nbsp;<input type='text' name='hargajual' id='hargajual' size='10' maxlength='10'
		class=\"easyui-validatebox\" data-options=\"required:true,validType:'length[1,20]'\"></td>
	</tr>
	<tr>
		<td>Stok Awal</td>
		<td>:&nbsp;<input type='text' name='stok' id='stok' size='5' maxlength='5'
		class=\"easyui-validatebox\" data-options=\"required:true,validType:'length[1,20]'\"></td>
	</tr>
	
	</table>
</div>";
?>
