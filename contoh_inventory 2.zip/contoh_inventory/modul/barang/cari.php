<?php
include "../../inc/inc.koneksi.php";

$table	= 'barang';
$id		= $_POST['id'];
$where	= "WHERE kode_barang='$id'";
$text	= "SELECT * FROM $table $where";
$sql 	= mysql_query($text);
$row	= mysql_num_rows($sql);
if ($row>0){
while ($r=mysql_fetch_array($sql)){	
	$data['namabarang']	= $r[nama_barang];
	$data['satuan']		= $r[satuan];
	$data['hargabeli']	= $r[harga_beli];
	$data['hargajual']	= $r[harga_jual];
	$data['stok']		= $r[stok_awal];
	echo json_encode($data);
}
}else{
	$data['namabarang']	= '';
	$data['satuan']		= '';
	$data['hargabeli']	= '';
	$data['hargajual']	= '';
	$data['stok']		= '';
	echo json_encode($data);
}
?>