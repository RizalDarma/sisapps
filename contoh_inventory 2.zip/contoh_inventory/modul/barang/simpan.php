<?php
include "../../inc/inc.koneksi.php";


$table		="barang";
$kode		=str_replace("'","\'",$_POST[kode]);
$nama		=str_replace("'","\'",$_POST[nama]);
$satuan		=$_POST[satuan];
$hargabeli	=str_replace(",","",$_POST[hargabeli]);
$hargajual	=str_replace(",","",$_POST[hargajual]);
$stok		=str_replace(",","",$_POST[stok]);

$where		= "WHERE kode_barang= '$kode'";

$sql = mysql_query("SELECT *
				   FROM $table 
				   $where");

$row	= mysql_num_rows($sql);
if ($row>0){

	$input	= "UPDATE $table SET 
				nama_barang		='$nama',
				satuan			='$satuan',
				harga_beli		='$hargabeli',
				harga_jual		='$hargajual',
				stok_awal		= '$stok'
				$where";
	
	mysql_query($input);								
	echo "<b>Data Sukses diubah</b>";
}else{
	$input = "INSERT INTO $table 
			(kode_barang,nama_barang,satuan,harga_beli,harga_jual,stok_awal)
			VALUES
			('$kode','$nama','$satuan','$hargabeli','$hargajual','$stok')";
	mysql_query($input);
	echo "<b>Data sukses disimpan</b>";
}
//echo "<br>".$input;
?>