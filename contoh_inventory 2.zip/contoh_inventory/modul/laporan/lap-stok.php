<?php
include '../../inc/inc.koneksi.php';
include '../../inc/fungsi_tanggal.php';

$sql = "SELECT kode_barang,nama_barang,satuan,harga_beli,harga_jual,stok_awal,
		if((SELECT sum(jmlbeli) FROM d_beli WHERE kode_barang=barang.kode_barang) is NULL,0,(SELECT sum(jmlbeli) FROM d_beli WHERE kode_barang=barang.kode_barang)) as jmlbeli,
		if((SELECT sum(jmljual) FROM d_jual WHERE kode_barang=barang.kode_barang) is NULL,0,(SELECT sum(jmljual) FROM d_jual WHERE kode_barang=barang.kode_barang)) as jmljual,
		((stok_awal+
		if((SELECT sum(jmlbeli) FROM d_beli WHERE kode_barang=barang.kode_barang) is NULL,0,(SELECT sum(jmlbeli) FROM d_beli WHERE kode_barang=barang.kode_barang)))-
		if((SELECT sum(jmljual) FROM d_jual WHERE kode_barang=barang.kode_barang) is NULL,0,(SELECT sum(jmljual) FROM d_jual WHERE kode_barang=barang.kode_barang)))	as stokakhir
				FROM barang ";

require_once ("fpdf.php");
$pdf = new FPDF('L','mm','A4');
$pdf->Open();
$pdf->addPage();
$pdf->setAutoPageBreak(false);
$pdf->setFont('Arial','',12);
$pdf->text(10,30,'SISTEM INFROMASI INVENTORY');
$pdf->text(10,36,'LAPORAN STOK BARANG');

//setting judul
$yi = 50;
$ya = 44;
$pdf->setFont('Arial','',9);
$pdf->setFillColor(222,222,222);
$pdf->setXY(10,$ya);
$pdf->CELL(6,6,'NO',1,0,'C',1);
$pdf->CELL(30,6,'KODE BARANG',1,0,'C',1);
$pdf->CELL(80,6,'NAMA BARANG',1,0,'C',1);
$pdf->CELL(20,6,'SATUAN',1,0,'C',1);
$pdf->CELL(30,6,'HARGA BELI',1,0,'C',1);
$pdf->CELL(30,6,'HARGA JUAL',1,0,'C',1);
$pdf->CELL(20,6,'AWAL',1,0,'C',1);
$pdf->CELL(20,6,'BELI',1,0,'C',1);
$pdf->CELL(20,6,'JUAL',1,0,'C',1);
$pdf->CELL(20,6,'AKHIR',1,0,'C',1);
$ya = $yi + $row;
$sql = mysql_query($sql);

//setting isi data
$i = 1;
$no = 1;
$max = 31;
$row = 6;
while($data = mysql_fetch_array($sql)){
	$pdf->setXY(10,$ya);
	$pdf->setFont('arial','',9);
	$pdf->setFillColor(255,255,255);
	$pdf->cell(6,6,$no,1,0,'C',1);
	$pdf->CELL(30,6,$data[kode_barang],1,0,'C',1);
	$pdf->CELL(80,6,$data[nama_barang],1,0,'L',1);
	$pdf->CELL(20,6,$data[satuan],1,0,'C',1);
	$pdf->CELL(30,6,number_format($data[harga_beli]),1,0,'R',1);
	$pdf->CELL(30,6,number_format($data[harga_jual]),1,0,'R',1);
	$pdf->CELL(20,6,number_format($data[stok_awal]),1,0,'R',1);
	$pdf->CELL(20,6,number_format($data[jmlbeli]),1,0,'R',1);
	$pdf->CELL(20,6,number_format($data[jmljual]),1,0,'R',1);
	$pdf->CELL(20,6,number_format($data[stokakhir]),1,0,'R',1);
	$ya = $ya+$row;
	$no++;
	$i++;
	//$dm[kode] = $data[kdprog];
}
$pdf->text(200,$ya+6,"SERANG , ".$tgl);
$pdf->text(200,$ya+18,"KEPALA CABANG");
$pdf->output();
?>