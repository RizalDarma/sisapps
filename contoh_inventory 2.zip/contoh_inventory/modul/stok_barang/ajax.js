// JavaScript Document
$(document).ready(function(){
	$(':input:not([type="submit"])').each(function() {
		$(this).focus(function() {
			$(this).addClass('hilite');
		}).blur(function() {
			$(this).removeClass('hilite');});
	});
	
	$(".data").flexigrid({
		  url : 'modul/stok_barang/post-json.php',
		  dataType : 'json',
		  colModel : [{display : 'No',name : 'no',width : 20,sortable : false,align : 'center'},
					  {display : 'Kode',name : 'kode_barang',width : 60,sortable : true,align : 'center'}, 
					  {display : 'Nama Barang',name : 'nama_barang',width : 180,sortable : true,align : 'left'}, 
					  {display : 'Satuan',name : 'satuan',width : 50,sortable : true,align : 'center'}, 
					  {display : 'Harga Beli',name : 'harga_beli',width : 60,sortable : true,align : 'right'},
					  {display : 'Harga Jual',name : 'harga_jual',width : 60,sortable : true,align : 'right'},
					  {display : 'Awal',name : 'stok_awal',width : 30,sortable : true,align : 'center'},
					  {display : 'Beli',name : 'jmlbeli',width : 30,sortable : true,align : 'center'},
					  {display : 'Jual',name : 'jmljual',width : 30,sortable : true,align : 'center'},
					  {display : 'Akhir',name : 'stokakhir',width : 30,sortable : true,align : 'center'}
		  ],
		  buttons : [{name : 'print',bclass : 'print',onpress : test},
					 {name : 'refresh',bclass : 'refresh',onpress : test}
		  ],
		  searchitems : [ 
			  {display : 'Kode',name : 'kode_barang',isdefault : true}, 
			  {display : 'Nama Barang',name : 'nama_barang'	} ,
			  {display : 'Satuan',name : 'satuan'	} 
		  ],
		  sortname : "kode_barang",
		  sortorder : "asc",
		  singleSelect : true,
		  usepager : true,
		  title : 'Daftar Barang',
		  useRp : true,
		  rp : 10,
		  showTableToggleBtn : false,
		  height : 300,
		  pagetext: 'Hal ',
		  outof: 's.d'
	  });
	  function test(com, grid) {
		  if (com == 'refresh') {
			   window.location.replace('media.php?module=lap_stok');
		  }else if (com == 'print') {
		  		//alert('Belum ada kode program');
				window.open("modul/laporan/lap-stok.php");
		  }
	  }

});