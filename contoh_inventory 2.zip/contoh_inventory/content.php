<?php
include "inc/inc.koneksi.php";
include "inc/library.php";
include "inc/fungsi_indotgl.php";
include "inc/fungsi_combobox.php";
include "inc/class_paging.php";
include "inc/fungsi_rupiah.php";
include "inc/fungsi_tanggal.php";
include "inc/fungsi_hdt.php";

$mod = $_GET['module'];

// Bagian Home
if ($mod=='home'){
	echo "<h2>Selamat Datang</h2>";
	echo "Selamat datang <b>$_SESSION[namalengkap] </b>, di Sistem Informas Inventory.";
	echo "<p align='justify'>Aplikasi ini kami buat sebagai contoh pembuatan alikasi kecil,
		dari aplikasi ini diharapkan pembeli dapat mempelajari alur minimal inventory dan code program
		dengan menggunakan PHP dan JQuery, adapun UserInterface JQuery yang digunakan adalah EasyUI serata Plugin FlexiGrid.</p>";
	echo "<p>Form Inventory Terdiri dari : </p>
		<ul>
			<li>Pengguna</li>
			<li>Barang</li>
			<li>Supplier</li>
			<li>Pembelian</li>
			<li>Penjualan</li>
			<li>Laporan Barang (PDF)</li>
			<li>Laporan Pembelian (HTML)</li>
			<li>Laporan Pembelian (Excel)</li>
			<li>Laporan Stok Barang (PDF)</li>
			<li>Grafik Pembelian</li>
			<li>Grafik Penjualan</li>
		</ul>";
	echo "Desain Database dan Relationalship<br>
		<img src='images/database.jpg'>";
	echo"<p>&nbsp;</p>
          <p align=right>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
  echo date("H:i:s");
  echo " WIB</p>";
  
}
//users
elseif ($mod=='pengguna'){
    include "modul/pengguna/index.php";
}
elseif ($mod=='barang'){
    include "modul/barang/index.php";
}
//supplier
elseif ($mod=='supplier'){
    include "modul/supplier/index.php";
}
elseif ($mod=='beli'){
    include "modul/beli/index.php";
}
elseif ($mod=='jual'){
    include "modul/jual/index.php";
}
//lap_barang
elseif ($mod=='lap_barang'){
    include "modul/lap_barang/index.php";
}
elseif ($mod=='lap_beli'){
    include "modul/lap_beli/index.php";
}
elseif ($mod=='lap_jual'){
    include "modul/lap_jual/index.php";
}
elseif ($mod=='lap_stok'){
    include "modul/stok_barang/index.php";
}
elseif ($mod=='grafik_beli'){
    include "modul/grafik_beli/index.php";
}
elseif ($mod=='grafik_jual'){
    include "modul/grafik_jual/index.php";
}

// Apabila modul tidak ditemukan
else{
  echo "<b>MODUL BELUM ADA ATAU BELUM LENGKAP</b>";
}
?>